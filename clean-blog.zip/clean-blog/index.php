<?php 
/**
 * Main index file of the theme.
 * 
 */

 get_header();

?>

    <!-- Main Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">
          
          <?php 

            if ( have_posts() ) :

              while( have_posts() ) : the_post();

                get_template_part( 'templates/content', get_post_format() );

              endwhile;

            endif;

          ?>

          <!-- Pager -->
          <div class="clearfix">
            <a class="btn btn-primary float-right" href="#">Older Posts &rarr;</a>
          </div>
        </div>
      </div>
    </div>

    <hr>

 <?php 
 get_footer();
 